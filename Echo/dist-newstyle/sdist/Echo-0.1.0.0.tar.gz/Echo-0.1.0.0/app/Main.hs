module Main where

import Network.Socket

main :: IO ()
main = putStrLn "Hello, Haskell!"
